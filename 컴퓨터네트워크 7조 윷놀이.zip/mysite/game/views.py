from django.shortcuts import render
from .models import Player1, Player2, Client, Yuut, Turn
import random
from .library import start, board, throw, select, play, move, ip, print_, count, left

def start_(request): #first counting clients and ordering
	tempnum=Turn(count=1)
	Turn.objects.all().delete()
	tempnum.save()
	start()
	count_=0
	seq_num=0
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip) #ip
	num=Client.objects.order_by('count')
	for i in num: #checking whether the client connected last time or not (saved in database or not)
		if (i.ip==real_ip):
			count_=1
			break
		seq_num+=1
	if(count_==0): #if not
		temp_num=Client(ip=real_ip, count=seq_num+1) #save and count(order) -> +1
		temp_num.save()
	
	clients=Client.objects.all()
	route=board()
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	
	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1,'second_finished': count2, 'second_left': left_2}) #only throwing

def throw_(request):
	tempnum=Turn.objects.all()[0]
	request_count=tempnum.count
	
	temp_ip=ip(request)
	your_yuut=Yuut.objects.all()[0]
	route=board()
	clients=Client.objects.all()
	yuut=print_()
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	
	if(temp_ip.count!=your_yuut.next): #not your turn
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors': 'not your turn', 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1,'second_finished': count2, 'second_left': left_2}) #read error
	if(request_count==1):
		temp=throw(temp_ip)
		if(temp==2):
			turn=Turn(count=1)
			Turn.objects.all().delete()
			turn.save()
			return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors': 'not error, just throw one more', 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
	
	clients=Client.objects.all()
	route=board()
	yuut=print_() 
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	turn=Turn(count=2)
	Turn.objects.all().delete()
	turn.save()
	
	yuut=print_()
	
	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'i':0, 'j':1, 'k':0, 'first_finished': count1, 'first_left': left_1,'second_finished': count2, 'second_left': left_2}) #only selecting

def select_(request):
	tempnum=Turn.objects.all()[0]
	request_count=tempnum.count
	
	clients=Client.objects.all()
	route=board()
	yuut=print_()
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	
	temp_ip=ip(request)
	if(request_count==2):
		if(request.GET['yuut']):
			if(request.GET['to_move']):
				temp_yuut=int(request.GET['yuut'])
				temp_move=int(request.GET['to_move'])
				temp=select(temp_yuut, temp_move, temp_ip)
				turn=Turn(count=2)
				Turn.objects.all().delete()
				turn.save()
				if (temp==1):
					return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'wrong, pick again', 'i':0, 'j':1, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2}) #read error
				elif (temp==2):
					return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'select again', 'i':0, 'j':1, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2}) #if yuut is moe or yuut
			else:
				return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'wrong, pick again', 'i':0, 'j':1, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
		else:
			return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'wrong, pick again', 'i':0, 'j':1, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
	turn=Turn(count=3)
	Turn.objects.all().delete()
	turn.save()
	

	clients=Client.objects.all()
	route=board()
	yuut=print_() 
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut, 'i':0, 'j':0, 'k':1, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2}) #only moving
	
def play_(request):
	tempnum=Turn.objects.all()[0]
	request_count=tempnum.count
	
	clients=Client.objects.all()
	route=board()
	yuut=print_() 
	player1=Player1.objects.all()
	player2=Player2.objects.all()
	count1=count(player1)
	count2=count(player2)
	left_1=left(player1)
	left_2=left(player2)
	
	temp_ip=ip(request)
	
	if(request_count==3):
		temp=play(temp_ip)
		turn=Turn(count=1)
		Turn.objects.all().delete()
		turn.save()
		clients=Client.objects.all()
		route=board()
		yuut=print_() 
		player1=Player1.objects.all()
		player2=Player2.objects.all()
		count1=count(player1)
		count2=count(player2)
		left_1=left(player1)
		left_2=left(player2)
		
		if(temp==1):
			return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'not error, you ate next players piece throw again', 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
		elif(temp==2):
			return render(request, 'game/victory.html', {'victory':'team1'})
		elif(temp==3):
			return render(request, 'game/victory.html', {'victory':'team2'})
		elif(temp==4):
			return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut, 'errors':'not error, next turn', 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
	else:
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut, 'errors':'not error, next turn', 'i':1, 'j':0, 'k':0, 'first_finished': count1, 'first_left': left_1, 'second_finished': count2, 'second_left': left_2})
