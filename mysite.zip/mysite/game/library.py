from .models import Player1, Player2, Client, Yuut
import random

def print_():
	temp=Yuut.objects.all()
	list1=[]
	for i in temp:
		if(i.yut!=0):
			if(i.yut==1):
				list1.append('doe')
			elif(i.yut==2):
				list1.append('gae')
			elif(i.yut==3):
				list1.append('girl')
			elif(i.yut==4):
				list1.append('yuut')
			elif(i.yut==5):
				list1.append('moe')
			elif(i.yut==6):
				list1.append('backdoe')
	return list1
				

def ip(self): #to save client's ip
	temp_ip=self.META['REMOTE_ADDR'].split('.') #save client's ip (without '.')
	new_ip="".join(temp_ip)[:] #join (temp_ip -> list)
	real_ip=int(new_ip) #type(int)
	ip=Client.objects.get(ip=real_ip) #pick one database (ip==real_ip)
	return ip

def start(): #first saving
	Player1.objects.all().delete()
	Player2.objects.all().delete()
	a=Player1(x=0, y=0, finish=0, together=1, order=1)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=2, order=2)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=3, order=3)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=4, order=4)
	a.save()
	
	b=Player2(x=0, y=0, finish=0, together=1, order=1)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=2, order=2)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=3, order=3)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=4, order=4)
	b.save()
	
	c=Yuut(yut=0, count=0, next=1, to_move=0)
	Yuut.objects.all().delete()
	c.save()
	
def board():
	def board_(self):
		a=0
		b=0
		c=0
		d=0
		for i in self:
			if (i.together==1):
				a+=1
			elif (i.together==2):
				b+=1
			elif (i.together==3):
				c+=1
			elif (i.together==4):
				d+=1
		if (a==0):
			a=1
		if (b==0):
			b=1
		if (c==0):
			c=1
		if (d==0):
			d=1
		list=[]
		list.append(a) #order -> 1 number
		list.append(b) #order -> 2 number
		list.append(c) #order -> 3 number
		list.append(d) #order -> 4 number
		return list
		
	route = [[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]],
	[[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0],[0,0,0]]]
	p_1=Player1.objects.all()
	p_2=Player2.objects.all()
	
	temp1=board_(p_1)
	for i in p_1:
		if(i.x!=-1 and i.y!=-1):
			route[i.x][i.y][0]=1
			route[i.x][i.y][1]=i.order
			if(i.together==i.order): #only big or lonely piece
				if(i.order==1): 
					if (temp1[0]>route[i.x][i.y][2]): #order 1's number is bigger
						route[i.x][i.y][2]=temp1[0]
				elif(i.order==2):
					if (temp1[1]>route[i.x][i.y][2]): #all same
						route[i.x][i.y][2]=temp1[1]
				elif(i.order==3):
					if (temp1[2]>route[i.x][i.y][2]):
						route[i.x][i.y][2]=temp1[2]
				elif(i.order==4):
					if (temp1[3]>route[i.x][i.y][2]):
						route[i.x][i.y][2]=temp1[3]
	temp2=board_(p_2)
	for j in p_2: #same
		if(j.x!=-1 and j.y!=-1):
			route[j.x][j.y][0]=2
			route[j.x][j.y][1]=j.order
			if(j.together==j.order):
				if(j.order==1):
					if (temp2[0]>route[j.x][j.y][2]):
						route[j.x][j.y][2]=temp2[0]
				elif(j.order==2):
					if (temp2[1]>route[j.x][j.y][2]):
						route[j.x][j.y][2]=temp2[1]
				elif(j.order==3):
					if (temp2[2]>route[j.x][j.y][2]):
						route[j.x][j.y][2]=temp2[2]
				elif(j.order==4):
					if (temp2[3]>route[j.x][j.y][2]):
						route[j.x][j.y][2]=temp2[3]
			
	return route
		
def throw(you):	
	your_yuut=Yuut.objects.all()[0]
	if(your_yuut.yut==0): #if yuut is zero (just for saving)
		Yuut.objects.filter(yut=0).delete() #all zero yuut delete
	
	if(you.count!=your_yuut.next): #not your turn
		return 1
	counting=0 #whether you throw one more or not
	yuut = 0 #making yuut
	first = random.randint(0,1)
	second = random.randint(0,1)
	third = random.randint(0,1)
	fourth = random.randint(0,1)
	yuut=first+second+third+fourth
	if(yuut==4 or yuut==0):
		counting=2
		if(yuut==0):
			yuut=4
		elif(yuut==4):
			yuut=5
	elif(yuut==1 and first==1):
		yuut=6 #backdoe
			
	temp=Yuut(yut=yuut, count=0, next=you.count, to_move=0) 
	
	temp.save() #saving yuut
	return counting

def select(yuut, move, you):
	checking=Yuut.objects.all()
	checking_num=0
	for i in checking: #to check if player don't pick the right yuut (example -> yuut=2, but player picked 3(girl)
		if (i.yut == yuut):
			if (i.count!=1):
				checking_num=1
	if (checking_num==0): #here it catches and reselect
		return 1
	
	if(you.count==1 or you.count==3): #team1
		current=Player1.objects.get(order=move)
		if(current.finish==1): #if the piece player picked is finished
			return 1
		elif (current.x==0 and current.y==0 and yuut==6): #0,0 backdoe
			return 1
		elif(current.together!=current.order): #to pick big piece(ate other pieces(same team)) 
			while(1):
				temp=Player1.objects.get(order=current.together)
				if(temp.together==temp.order):
					move=temp.order
					break;
	elif(you.count==2 or you.count==4): #same
		current=Player2.objects.get(order=move)
		if(current.finish==1):
			return 1
		elif (current.x==0 and current.y==0 and yuut==6):
			return 1
		elif(current.together!=current.order):
			while(1):
				temp=Player2.objects.get(order=current.together)
				if(temp.together==temp.order):
					move=temp.order
					break;
	
	your_yuut=Yuut.objects.filter(yut=yuut)
	check=0
	for i in your_yuut: #to save yuut (you picked which to move so save)
		if (i.count!=1):
			moved=Yuut(yut=i.yut, count=1, next=i.next, to_move=move)
			i.delete()
			moved.save()
			break #saved and break
	to_check=Yuut.objects.all()
	for j in to_check: #if other yuut is not picked which to move reselect
		if (j.count!=1):
			check=1
	if (check==1):
		return 2
	return 0
		
			
def play(you):
	temp_yuut=Yuut.objects.all()
	
	j=Player1.objects.all()
	k=Player2.objects.all()
	count=0
	
	for a in temp_yuut: #all saved yuuts
		current_yuut=a
	
		if(you.count==1 or you.count==3):
			current_player=Player1.objects.get(order=current_yuut.to_move) #the piece you picked
			
			if(move(current_player, current_yuut.yut, 1)): #move, eat, eat same team, finish, etc (and if you eat other team's piece)
				current_yuut.delete()
				zero=Yuut(yut=0, count=0, next=current_yuut.next, to_move=0) #delete moved yuut
				zero.save() #save
				return 1 #rethrow
			current_yuut.delete() #if you didn't eat other team's piece
				
			for i in j:
				if (i.finish==1): #checking finished pieces
					count+=1
			if (count==4): #if all finished
				Client.objects.all().delete()
				return 2 #over
		
		elif(you.count==2 or you.count==4): #same
			current_player=Player2.objects.get(order=current_yuut.to_move)
			
			if(move(current_player, current_yuut.yut, 2)):
				current_yuut.delete()
				zero=Yuut(yut=0, count=0, next=current_yuut.next, to_move=0)
				zero.save()
				return 1
			current_yuut.delete()
			
			
			for i in k:
				if (i.finish==1):
					count+=1
			if (count==4):
				Client.objects.all().delete()
				return 3
	
	num=you.count+1
	q=0
	for p in Client.objects.all(): #changing turn
		q+=1
	if(num>q):
		num=1
	reyuut=Yuut(yut=0, count=0, next=num, to_move=0) #saving empty yuut
	Yuut.objects.all().delete()
	reyuut.save()
	
	return 4 #next turn
	
def move(self, yuut, team):
	if (yuut==6): #correcting backdoe
		yuut=-1
	if(self.x==0 and self.y==0 and self.finish==-1): #last 0,0
		if(yuut==-1): #if backdoe -> right
			self.x=1
		else: #over
			self.x=-1
			self.y=-1
	self.finish=-1 #if piece starts, finish->-1, not started yet-> finish=0, finished->1
	if (self.x==0): #going down (start)
		if(self.y==0):
			self.y=yuut
		elif (self.y==5): #changing direction (first corner shortcut)
			if(yuut==5): 
				self.x=7 #it's correct don't touch
				self.y=1
			elif(yuut==-1):
				self.y=4
			else:
				self.x=yuut
				self.y=5-yuut
		elif(self.y+yuut>4):
			self.x=self.y+yuut-5
			self.y=5
		else:
			if(self.y==1 and yuut==-1):
				self.y=0
				self.finish=0
			else:
				self.y=self.y+yuut
	
	elif (self.y==5):
		if (self.x==5):
			if (yuut==5):
				self.x=7
				self.y=7
			elif(yuut==-1):
				self.x=4
			else:
				self.x=5-yuut
				self.y=5-yuut
		elif (self.x+yuut>4):
			self.y=5-(self.x+yuut-5)
			self.x=5
		else:
			self.x=self.x+yuut
	
	elif (self.x==5):
		if (self.y==0):
			if(yuut==-1):
				self.y=1
			else:
				self.x=5-yuut
		elif (self.y-yuut<0):
			self.x=5-yuut+self.y
			self.y=0
		else:
			self.y=self.y-yuut
	elif (self.y==0):
		if (self.x-yuut<0):
			self.y=-1
			self.x=-1
		else:
			self.x=self.x-yuut
	
	else:
		if ((self.x<3 and self.y>2) or (self.x>3 and self.y<3)):
			if(self.x+yuut>5):
				if (self.x==7):
					if (yuut==-1):
						self.x=4
						self.y=1
					else:
						self.x=5-(self.x+yuut-8)
						self.y=0
				else:									
					self.x=5-(self.x+yuut-6)
					self.y=0
			else:
				if(self.x+yuut==5):
					self.x=7
					self.y=1
				else:
					self.x=self.x+yuut
					self.y=self.y-yuut
		else:
			if(self.x-yuut<-1 or self.y==7):
				if(self.y==7):
					if(yuut==-1):
						self.x=1
						self.y=1
					elif(yuut>1):
						self.x=-1
						self.y=-1
					else:
						self.x=0
						self.y=0
				else:
					self.y=-1
					self.x=-1
			else:	
				if(self.x-yuut==0):
					self.x=7
					self.y=7
				elif(self.x-yuut==-1):
					self.x=0
					self.y=0
				else:
					self.x=self.x-yuut
					self.y=self.y-yuut #just moving over

	if (self.x==3 and self.y==2): #center (3,2)->(2,2)
		self.x=2					

	if (self.x==-1 and self.y==-1): #if over
		self.finish=1
		
	team_1=Player1.objects.all()
	team_2=Player2.objects.all()
	
	re=0
	
	if (team==1): #eat, eat same team, eaten pieces moving
		all1=Player1.objects.all()
		for i in all1:
			if (i.together==self.order): #if the piece is eaten by self -> move to self
				temp_1=Player1(x=self.x, y=self.y, finish=self.finish, together=i.together, order=i.order)
				Player1.objects.get(order=i.order).delete()
				temp_1.save() #save
		to_save=Player1(x=self.x, y=self.y, finish=self.finish, together=self.together, order=self.order) #self save
		Player1.objects.get(order=self.order).delete()
		to_save.save()
		for i in team_1: #if you eat same team's piece
			if (i.x == self.x and i.y == self.y):
				if(i.together!=self.order): #not what you ate already
					if(i.finish==-1): #not (0,0) piece (not started)
						temp3=Player1(x=self.x, y=self.y, finish=self.finish, together=self.order, order=i.order) #together -> self's order (eat the piece)
						Player1.objects.get(order=i.order).delete()
						temp3.save() #save
		for j in team_2: #if you eat other team's piece
			if (j.x == self.x and j.y == self.y):
				if (j.finish==-1): #not (0,0) piece (not started)
					temp4=Player2(x=0, y=0, finish=0, together=j.order, order=j.order) #eaten piece to (0,0), finish=0
					Player2.objects.get(order=j.order).delete()
					temp4.save() #save
					re=1 #rethrow
		
		
	elif(team==2): #same
		all2=Player2.objects.all()
		for i in all2:
			if (i.together==self.order):
				temp_2=Player2(x=self.x, y=self.y, finish=self.finish, together=i.together, order=i.order)
				Player2.objects.get(order=i.order).delete()
				temp_2.save()
		to_save=Player2(x=self.x, y=self.y, finish=self.finish, together=self.together, order=self.order)
		Player2.objects.get(order=self.order).delete()
		to_save.save()
		for i in team_2:
			if (i.x == self.x and i.y == self.y):
				if(i.together!=self.order):
					if(i.finish==-1):
						temp3=Player2(x=self.x, y=self.y, finish=self.finish, together=self.order, order=i.order)
						Player2.objects.get(order=i.order).delete()
						temp3.save()
		for j in team_1:
			if (j.x == self.x and j.y == self.y):
				if (j.finish==-1):
					temp4=Player1(x=0, y=0, finish=0, together=j.order, order=j.order)
					Player1.objects.get(order=j.order).delete()
					temp4.save()
					re=1
	
	return re
