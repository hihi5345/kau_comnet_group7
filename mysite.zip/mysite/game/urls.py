from django.conf.urls import url
from game import views

urlpatterns = [
    url(r'^$', views.start_, name='start'),
    url(r'^throw/', views.throw_, name='throw'),
    url(r'^select/', views.select_, name='select'),
    url(r'^play/', views.play_, name='play')
]