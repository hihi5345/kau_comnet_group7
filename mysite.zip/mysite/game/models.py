from django.db import models

class Client(models.Model):
	ip = models.IntegerField(default=0)
	count = models.IntegerField(default=0)
	
	def __str__(self):
		return '%i %i' %(self.ip, self.count)

class Yuut(models.Model):
	yut = models.IntegerField(default=0)
	count = models.IntegerField(default=0)
	next = models.IntegerField(default=1)
	to_move = models.IntegerField(default=0)
	
	def __str__(self):
		return '%i %i %i %i' %(self.yut, self.count, self.next, self.to_move)
	
class Player1(models.Model):
	x = models.IntegerField(default=0)
	y = models.IntegerField(default=0)
	finish = models.IntegerField(default=0)
	together = models.IntegerField(default=0)
	order = models.IntegerField(default=0)
	
	def __str__(self):
		return '%i %i %i %i %i' %(self.x, self.y, self.finish, self. together, self.order)
		
class Player2(models.Model):
	x = models.IntegerField(default=0)
	y = models.IntegerField(default=0)
	finish = models.IntegerField(default=0)
	together = models.IntegerField(default=0)
	order = models.IntegerField(default=0)
	
	def __str__(self):
		return '%i %i %i %i %i' %(self.x, self.y, self.finish, self.together, self.order)

	