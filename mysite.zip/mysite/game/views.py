from django.shortcuts import render
from django.template import loader
from django.http import HttpResponse
from .models import Player1, Player2, Client, Yuut
import random

def start(request):
	Player1.objects.all().delete()
	Player2.objects.all().delete()
	a=Player1(x=0, y=0, finish=0, together=1, order=1)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=2, order=2)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=3, order=3)
	a.save()
	a=Player1(x=0, y=0, finish=0, together=4, order=4)
	a.save()
	
	b=Player2(x=0, y=0, finish=0, together=1, order=1)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=2, order=2)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=3, order=3)
	b.save()
	b=Player2(x=0, y=0, finish=0, together=4, order=4)
	b.save()
	
	c=Yuut(yut=0, count=0, next=1, to_move=0)
	Yuut.objects.all().delete()
	c.save()

	count_=0
	seq_num=0
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip)
	num=Client.objects.order_by('count')
	for i in num:
		if (i.ip==real_ip):
			count_=1
			break
		seq_num+=1
	if(count_==0):
		temp_num=Client(ip=real_ip, count=seq_num+1)
		temp_num.save()
	
	k=Client.objects.all()
	
	return render(request, 'game/board.html', {'clients': k})

def board(request):
	route = [[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0]]

        p_1=Player1.objects.all()
	p_2=Player2.objects.all()
	for i in p_1:
		for j in p_2:
			route[p_1.x][p_1.y]=1
			route[p_2.x][p_2.y]=2
 
	return render(request, 'game/board.html', {'route':route})

def throw(request):
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip)
	your_num=Client.objects.get(ip=real_ip)
	your_yuut=Yuut.objects.all()[0]
	
	
	
	if(your_num.count!=your_yuut.next):
		return render(request, 'game/board.html', {})
	
	if(your_yuut.yut==0):
		Yuut.objects.filter(yut=0).delete()
	
	counting=0
	yuut = 0
	first = random.randint(0,1)
	second = random.randint(0,1)
	third = random.randint(0,1)
	fourth = random.randint(0,1)
	yuut=first+second+third+fourth
	if(yuut==4 or yuut==0):
		counting=1
		if(yuut==0):
			yuut=4
		elif(yuut==4):
			yuut=5
		elif(yuut==1 and first==1):
			yuut=6
			
	temp=Yuut(yut=yuut, count=0, next=your_num.count, to_move=0)
	
	temp.save()
	
	if(counting==1):
		return render(request, 'game/board.html', {})
	
	k=Yuut.objects.all()
	l=Player1.objects.all()
	
	return render(request, 'game/moving.html', {'yuut': k, 'player1': l})

def select(request):
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip)
	your_num=Client.objects.get(ip=real_ip)
	
	temp_move=int(request.GET['to_move'][0])
	temp_yuut=int(request.GET['to_move'][1])
	if (temp_yuut>6 or temp_yuut<1):
		return render(request, 'game/moving.html', {})
	if (temp_move>4 or temp_move<1):
		return render(request, 'game/moving.html', {})
	checking=Yuut.objects.all()
	checking_num=0
	if (temp_yuut==6):
		temp_yuut=-1
	for i in checking:
		if (i.yut == temp_yuut):
			if (i.count!=1):
				checking_num=1
	if (checking_num==0):
		return render(request, 'game/moving.html', {})
	
	if(your_num.count==1 or your_num.count==3):
		current=Player1.objects.get(order=temp_move)
		if(current.finish==1):
			return render(request, 'game/moving.html', {})
		elif (current.x==0 and current.y==0 and temp_yuut==-1):
			return render(request, 'game/moving.html', {})
		elif(current.together!=current.order):
			while(1):
				temp=Player1.objects.get(order=current.together)
				if(temp.together==temp.order):
					temp_move=temp.order
					break;
	elif(your_num.count==2 or your_num.count==4):
		current=Player2.objects.get(order=temp_move)
		if(current.finish==1):
			return render(request, 'game/moving.html', {})
		elif(current.together!=current.order):
			while(1):
				temp=Player2.objects.get(order=current.together)
				if(temp.together==temp.order):
					temp_move=temp.order
					break;
	
	your_yuut=Yuut.objects.filter(yut=temp_yuut)
	check=0
	for i in your_yuut:
		if (i.count!=1):
			moved=Yuut(yut=i.yut, count=1, next=i.next, to_move=temp_move)
			i.delete()
			moved.save()
			break
	to_check=Yuut.objects.all()
	for j in to_check:
		if (j.count!=1):
			check=1
	k=Yuut.objects.all()
	if (check==1):
		return render(request, 'game/moving.html', {'yuut':k})
	return render(request, 'game/start.html', {'yuut':k})
	
def play(request):
	def move(self, yuut, team):
		
		self.finish=-1
		if (self.x==0):
			if(self.y==0):
				if(yuut!=-1):
					self.y=yuut
			elif (self.y==5):
				if(yuut==5):
					self.x=7
					self.y=1
				elif(yuut==-1):
					self.y=4
				else:
					self.x=yuut
					self.y=5-yuut
			elif(self.y+yuut>4):
				self.x=self.y+yuut-5
				self.y=5
			else:
				self.y=self.y+yuut
		
		elif (self.y==5):
			if (self.x==5):
				if (yuut==5):
					self.x=7
					self.y=7
				elif(yuut==-1):
					self.x=4
				else:
					self.x=5-yuut
					self.y=5-yuut
			elif (self.x+yuut>4):
				self.y=5-(self.x+yuut-5)
				self.x=5
			else:
				self.x=self.x+yuut
		
		elif (self.x==5):
			if (self.y==0):
				if(yuut==-1):
					self.y=1
				else:
					self.x=5-yuut
			elif (self.y-yuut<0):
				self.x=5-yuut+self.y
				self.y=0
			else:
				self.y=self.y-yuut
		elif (self.y==0):
			if (self.x-yuut<-1):
				self.y=-1
				self.x=-1
			else:
				self.x=self.x-yuut
		
		else:
			if ((self.x<3 and self.y>2) or (self.x>3 and self.y<3)):
				if(self.x+yuut>5):
					if (self.x==7):
						if (yuut==-1):
							self.x=4
							self.y=1
						else:
							self.x=5-(self.x+yuut-8)
							self.y=0
					else:									
						self.x=5-(self.x+yuut-6)
						self.y=0
				else:
					if(self.x+yuut==5):
						self.x=7
						self.y=1
					else:
						self.x=self.x+yuut
						self.y=self.y-yuut
			else:
				if(self.x-yuut<-1 or self.y==7):
					if(self.y==7):
						if(yuut==-1):
							self.x=1
							self.y=1
						else:
							if(yuut>1):
								self.x=-1
								self.y=-1
							else:
								self.x=0
								self.y=0
					else:
						self.y=-1
						self.x=-1
				else:	
					if(self.x-yuut==0):
						self.x=7
						self.y=7
					else:
						self.x=self.x-yuut
						self.y=self.y-yuut	
		
		if (self.x==3 and self.y==2):
			self.x=2
		
		if (self.x==-1 and self.y==-1):
			if (yuut!=-1):
				self.finish=1
			
		team_1=Player1.objects.all()
		team_2=Player2.objects.all()
		
		re=0
		
		if (team==1):
			all1=Player1.objects.all()
			for i in all1:
				if (i.together==self.order):
					temp_1=Player1(x=self.x, y=self.y, finish=self.finish, together=i.together, order=i.order)
					Player1.objects.get(order=i.order).delete()
					temp_1.save()
			to_save=Player1(x=self.x, y=self.y, finish=self.finish, together=self.together, order=self.order)
			Player1.objects.get(order=self.order).delete()
			to_save.save()
			for i in team_1:
				if (i.x == self.x and i.y == self.y):
					if(i.together!=self.order):
						if(i.finish==-1):
							temp3=Player1(x=self.x, y=self.y, finish=self.finish, together=self.order, order=i.order)
							Player1.objects.get(order=i.order).delete()
							temp3.save()
			for j in team_2:
				if (j.x == self.x and j.y == self.y):
					if (j.finish==-1):
						temp4=Player2(x=0, y=0, finish=0, together=j.order, order=j.order)
						Player2.objects.get(order=j.order).delete()
						temp4.save()
						re=1
			
			
		elif(team==2):
			all2=Player2.objects.all()
			for i in all2:
				if (i.together==self.order):
					temp_2=Player2(x=self.x, y=self.y, finish=self.finish, together=i.together, order=i.order)
					Player2.objects.get(order=i.order).delete()
					temp_2.save()
			to_save=Player2(x=self.x, y=self.y, finish=self.finish, together=self.together, order=self.order)
			Player2.objects.get(order=self.order).delete()
			to_save.save()
			for i in team_2:
				if (i.x == self.x and i.y == self.y):
					if(i.together!=self.order):
						if(i.finish==-1):
							temp3=Player2(x=self.x, y=self.y, finish=self.finish, together=self.order, order=i.order)
							Player2.objects.get(order=i.order).delete()
							temp3.save()
			for j in team_1:
				if (j.x == self.x and j.y == self.y):
					if (j.finish==-1):
						temp4=Player1(x=0, y=0, finish=0, together=j.order, order=j.order)
						Player1.objects.get(order=j.order).delete()
						temp4.save()
						re=1
		
		return re
	
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip)
	your_num=Client.objects.get(ip=real_ip)
	temp_yuut=Yuut.objects.all()
	
	j=Player1.objects.all()
	k=Player2.objects.all()
	count=0
	
	check=0
	for a in temp_yuut:
		current_yuut=a
	
		if(your_num.count==1 or your_num.count==3):
			current_player=Player1.objects.get(order=current_yuut.to_move)
			
			if(move(current_player, current_yuut.yut, 1)):
				current_yuut.delete()
				zero=Yuut(yut=0, count=0, next=current_yuut.next, to_move=0)
				zero.save()
				return render(request, 'game/board.html', {})
			current_yuut.delete()
				
			for i in j:
				if (i.finish==1):
					count+=1
			if (count==4):
				Client.objects.all().delete()
				return render(request, 'game/victory.html', {'victory':'team1'})
		
		elif(your_num.count==2 or your_num.count==4):
			current_player=Player2.objects.get(order=current_yuut.to_move)
			
			if(move(current_player, current_yuut.yut, 2)):
				current_yuut.delete()
				zero=Yuut(yut=0, count=0, next=current_yuut.next, to_move=0)
				zero.save()
				return render(request, 'game/board.html', {})
			current_yuut.delete()
			
			
			for i in k:
				if (i.finish==1):
					count+=1
			if (count==4):
				Client.objects.all().delete()
				return render(request, 'game/victory.html', {'victory':'team2'})
	
	num=your_num.count+1
	q=0
	for p in Client.objects.all():
		q+=1
	if(num>q):
		num=1
	reyuut=Yuut(yut=0, count=0, next=num, to_move=0)
	Yuut.objects.all().delete()
	reyuut.save()
	
	return render(request, 'game/board.html', {})
