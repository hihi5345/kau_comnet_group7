from django.shortcuts import render
from .models import Player1, Player2, Client, Yuut
import random
from .library import start, board, throw, select, play, move, ip, print_

def start_(request): #first counting clients and ordering 
	start()
	count_=0
	seq_num=0
	temp_ip=request.META['REMOTE_ADDR'].split('.')
	new_ip="".join(temp_ip)[:]
	real_ip=int(new_ip) #ip
	num=Client.objects.order_by('count')
	for i in num: #checking whether the client connected last time or not (saved in database or not)
		if (i.ip==real_ip):
			count_=1
			break
		seq_num+=1
	if(count_==0): #if not
		temp_num=Client(ip=real_ip, count=seq_num+1) #save and count(order) -> +1
		temp_num.save()
	
	clients=Client.objects.all()
	route=board()
	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'i':1, 'j':0, 'k':0}) #only throwing

def throw_(request):
	temp_ip=ip(request)
	
	clients=Client.objects.all()
	route=board()
	
	temp=throw(temp_ip)
	yuut=print_()
	if(temp==1):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors': 'not your turn', 'i':1, 'j':0, 'k':0}) #read error
	elif(temp==2):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors': 'not error, just throw one more', 'i':1, 'j':0, 'k':0})

	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'i':0, 'j':1, 'k':0}) #only selecting

def select_(request):
	temp_ip=ip(request)
	temp_move=int(request.GET['to_move']) #the piece to move (html first radio type
	temp_yuut=int(request.GET['yuut']) #the yuut (html second radio type
	
	temp=select(temp_yuut, temp_move, temp_ip)
	
	clients=Client.objects.all()
	route=board()
	yuut=print_()
	if (temp==1):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'wrong, pick again', 'i':0, 'j':1, 'k':0}) #read error
	elif (temp==2):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'select again', 'i':0, 'j':1, 'k':0}) #if yuut is moe or yuut
	return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut, 'i':0, 'j':0, 'k':1}) #only moving
	
def play_(request):
	temp_ip=ip(request)

	temp=play(temp_ip)
	clients=Client.objects.all()
	route=board()
	yuut=print_() #not using you must change this to yuut=Yuut.objects.all() or correct this
	if(temp==1):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut,'errors':'not error, you ate next players piece throw again', 'i':1, 'j':0, 'k':0})
	elif(temp==2):
		return render(request, 'game/victory.html', {'victory':'team1'})
	elif(temp==3):
		return render(request, 'game/victory.html', {'victory':'team2'})
	elif(temp==4):
		return render(request, 'game/realboard.html', {'route':route, 'clients':clients, 'yuuts':yuut, 'errors':'not error, next turn', 'i':1, 'j':0, 'k':0})





