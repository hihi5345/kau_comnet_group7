from django.db import models

class Turn(models.Model):
	count = models.IntegerField(default=0)

class Client(models.Model):
	ip = models.IntegerField(default=0) #the ip address (no '.' and int)
	count = models.IntegerField(default=0) #client's order
	
	def __str__(self):
		return '%i %i' %(self.ip, self.count)

class Yuut(models.Model):
	yut = models.IntegerField(default=0) #yuut
	count = models.IntegerField(default=0) #if yuut picked which to move, count -> 1
	next = models.IntegerField(default=1) #current turn
	to_move = models.IntegerField(default=0) #which to move
	
	def __str__(self):
		return '%i %i %i %i' %(self.yut, self.count, self.next, self.to_move)
	
class Player1(models.Model):
	x = models.IntegerField(default=0) #x
	y = models.IntegerField(default=0) #y
	finish = models.IntegerField(default=0) #to check
	together = models.IntegerField(default=0) #if together!=order, then it's eaten by other piece
	order = models.IntegerField(default=0) #order 1,2,3,4
	
	def __str__(self):
		return '%i %i %i %i %i' %(self.x, self.y, self.finish, self. together, self.order)
		
class Player2(models.Model):
	x = models.IntegerField(default=0) #same
	y = models.IntegerField(default=0)
	finish = models.IntegerField(default=0)
	together = models.IntegerField(default=0)
	order = models.IntegerField(default=0)
	
	def __str__(self):
		return '%i %i %i %i %i' %(self.x, self.y, self.finish, self.together, self.order)

	