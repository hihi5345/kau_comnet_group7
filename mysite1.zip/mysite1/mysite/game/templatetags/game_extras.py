from django import template

register = template.Library()

@register.assignment_tag
def ok(a, b, x):
	if (a==x[0]):
		if (b==x[1]):
			return True
	else:
		return False	
	