from django.conf.urls import url
from game import views

urlpatterns = [
    url(r'^$', views.start, name='start'),
    url(r'^throw/', views.throw, name='throw'),
    url(r'^select/', views.select, name='select'),
    url(r'^play/', views.play, name='play'),
    url(r'^board/', views.board, name='board')
]